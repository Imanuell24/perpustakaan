<div class="container-fluid">
   
    <style>
        .card-hover {
            transition: all 0.3s ease-in-out;
            cursor: pointer;
            border-radius: 10px;
        }

        .card-hover:hover {
            transform: translateY(-8px);
            box-shadow: 0 15px 30px rgba(0,0,0,0.2);
        }

        .card-hover i {
            transition: 0.3s;
        }

        .card-hover:hover i {
            transform: scale(1.2);
        }

        .card-hover a {
            text-decoration: none;
            color: inherit;
        }

        .welcome-card {
            position: relative;
            background: linear-gradient(135deg, #4e73df, #224abe);
            border-radius: 15px;
            overflow: hidden;
            transition: 0.3s;
        }

        .welcome-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 40px rgba(0,0,0,0.25);
        }

        .welcome-icon-bg {
            position: absolute;
            right: -30px;
            bottom: -20px;
            font-size: 150px;
            opacity: 0.08;
        }

        .welcome-text h3 {
            font-weight: 700;
        }

        .welcome-text p {
            font-size: 16px;
            opacity: 0.9;
        }

        .stat-card {
            border: none;
            border-radius: 15px;
            color: white;
            transition: 0.3s ease;
            cursor: pointer;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.2);
        }

        .bg-gradient-primary {
            background: linear-gradient(45deg, #2563eb, #3b82f6);
        }

        .bg-gradient-success {
            background: linear-gradient(45deg, #16a34a, #22c55e);
        }

        .bg-gradient-warning {
            background: linear-gradient(45deg, #d97706, #f59e0b);
        }

        .bg-gradient-danger {
            background: linear-gradient(45deg, #dc2626, #ef4444);
        }
    
    </style>
    
    <div class="row mb-4">
        <div class="col-12">
            <div class="card text-white welcome-card shadow border-0">
                <div class="card-body welcome-text">

                    <h3 class="mb-2 text-white">
                        <i class="fa fa-university"></i> PERPUSTAKAAN CALZ SCHOOL 
                    </h3>

                    <p class="mb-1">
                        Selamat datang,
                    </p>

                    <h4 class="mb-0 text-white">
                        <?= $this->session->userdata('nama'); ?>
                        👋
                    </h4>

                    <small>
                        Semoga harimu menyenangkan 📚✨
                    </small>

                    <i class="fa fa-book welcome-icon-bg"></i>

                </div>
            </div>
        </div>
    </div>
        <div class="container-fluid">
    <div class="row">
        <div class="col-md-3 mb-4">
            <div class="card stat-card bg-gradient-primary">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="text-white">Total Anggota</h6>
                        <h2 class="text-white"><?= $total_anggota ?></h2>
                    </div>
                    <i class="fas fa-users fa-3x"></i>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-4">
            <div class="card stat-card bg-gradient-success">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="text-white">Total Buku</h6>
                        <h2 class="text-white"><?= $total_buku ?></h2>
                    </div>
                    <i class="fas fa-book fa-3x"></i>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-4">
            <div class="card stat-card bg-gradient-warning">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="text-white">Total Peminjaman</h6>
                        <h2 class="text-white"><?= $total_peminjaman ?></h2>
                    </div>
                    <i class="fas fa-book-reader fa-3x"></i>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-4">
            <div class="card stat-card bg-gradient-danger">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="text-white">Total Pengembalian</h6>
                        <h2 class="text-white"><?= $total_pengembalian ?></h2>
                    </div>
                    <i class="fas fa-undo fa-3x"></i>
                </div>
            </div>
        </div>

    </div>

    <?php if ($this->session->userdata('role') == 'admin'): ?>

    <div class="row">
        <div class="col-md-4">
            <a href="<?= site_url('data-anggota') ?>">
                <div class="card shadow-sm border-left-primary card-hover">
                    <div class="card-body text-center">
                        <i class="fa fa-users fa-3x text-primary mb-3"></i>
                        <h5>Kelola Anggota</h5>
                        <p class="text-muted">Tambah & kelola data anggota perpustakaan.</p>
                    </div>
                </div>
            </a>
        </div>

        <div class="col-md-4">
            <a href="<?= site_url('data-buku') ?>">
                <div class="card shadow-sm border-left-success card-hover">
                    <div class="card-body text-center">
                        <i class="fa fa-book fa-3x text-success mb-3"></i>
                        <h5>Kelola Buku</h5>
                        <p class="text-muted">Manajemen data buku & stok.</p>
                    </div>
                </div>
            </a>
        </div>

        <div class="col-md-4">
            <a href="<?= site_url('data-peminjaman') ?>">
                <div class="card shadow-sm border-left-danger card-hover">
                    <div class="card-body text-center">
                        <i class="fa fa-exchange-alt fa-3x text-danger mb-3"></i>
                        <h5>Transaksi</h5>
                        <p class="text-muted">Kelola peminjaman & pengembalian.</p>
                    </div>
                </div>
            </a>
        </div>
    </div>
</div>

    <?php else: ?>

    <div class="row">

        <div class="col-md-6">
            <a href="<?= site_url('data-peminjaman') ?>">
                <div class="card shadow-sm border-left-primary card-hover">
                    <div class="card-body text-center">
                        <i class="fa fa-book fa-3x text-primary mb-3"></i>
                        <h5>Peminjaman Buku</h5>
                        <p class="text-muted">Pinjam buku yang tersedia di perpustakaan.</p>
                    </div>
                </div>
            </a>
        </div>

        <div class="col-md-6">
            <a href="<?= site_url('data-pengembalian') ?>">
                <div class="card shadow-sm border-left-success card-hover">
                    <div class="card-body text-center">
                        <i class="fa fa-undo fa-3x text-success mb-3"></i>
                        <h5>Pengembalian Buku</h5>
                        <p class="text-muted">Kembalikan buku yang sudah dipinjam.</p>
                    </div>
                </div>
            </a>
        </div>

    </div>

    <?php endif; ?>

</div>