<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Registrasi Anggota</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?= base_url('assets/vendor/bootstrap/css/bootstrap.min.css') ?>">

    <!-- Font Awesome -->
    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <style>
        body {
            background: linear-gradient(135deg, #1e3c72, #2a5298);
            min-height: 100vh;
        }

        .register-card {
            border: none;
            border-radius: 15px;
            overflow: hidden;
            transition: 0.3s;
        }

        .register-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 40px rgba(0,0,0,0.3);
        }

        .card-header {
            background: linear-gradient(135deg, #4e73df, #224abe);
        }

        .form-control {
            border-radius: 8px;
        }

        .input-group-text {
            background-color: #4e73df;
            color: white;
            border: none;
        }

        .btn-primary {
            background: linear-gradient(135deg, #4e73df, #224abe);
            border: none;
            border-radius: 8px;
            transition: 0.3s;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.2);
        }

        .btn-secondary {
            border-radius: 8px;
        }

        .title-text {
            font-weight: 700;
        }

        .sub-text {
            font-size: 14px;
            opacity: 0.9;
        }
    </style>
</head>

<body>

<div class="container d-flex justify-content-center align-items-center" style="min-height:100vh;">
    <div class="col-lg-5 col-md-7 col-sm-10">

        <div class="card register-card shadow-lg">
            <div class="card-header text-white text-center py-4">
                <h4 class="mb-1 title-text">
                    <i class="fas fa-user-plus"></i> Registrasi Anggota
                </h4>
                <small class="sub-text">Buat akun untuk mengakses sistem perpustakaan</small>
            </div>

            <div class="card-body p-4">
                <form id="form-anggota">

                    <div class="form-group">
                        <label>NIS</label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fas fa-id-card"></i></span>
                            </div>
                            <input type="text" class="form-control" name="nis">
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Nama Siswa</label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fas fa-user"></i></span>
                            </div>
                            <input type="text" class="form-control" name="nm_siswa">
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Kelas</label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fas fa-school"></i></span>
                            </div>
                            <input type="text" class="form-control" name="kelas">
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Alamat</label>
                        <textarea class="form-control" name="alamat" rows="2"></textarea>
                    </div>

                    <hr>

                    <small class="text-muted d-block mb-3">
                        <b>Pembuatan User Login</b>
                    </small>

                    <div class="form-group">
                        <label>Username</label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fas fa-user-circle"></i></span>
                            </div>
                            <input type="text" class="form-control" id="username" name="username">
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Password</label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fas fa-lock"></i></span>
                            </div>
                            <input type="password" class="form-control" id="password" name="password">
                        </div>
                    </div>

                </form>

                <button class="btn btn-primary btn-block mt-3" id="btn-simpan">
                    <i class="fas fa-save"></i> Proses Registrasi
                </button>

                <a href="<?= site_url('login-sistem') ?>" class="btn btn-light btn-block mt-2">
                    <i class="fas fa-sign-in-alt"></i> Sudah punya akun? Login
                </a>
            </div>
        </div>

    </div>
</div>
<script src="<?=base_url()?>assets/plugins/jquery/jquery.min.js"></script>
<script src="<?= base_url('assets/vendor/bootstrap/js/bootstrap.bundle.min.js') ?>"></script>

<script>
$(document).ready(function () {

    $('#btn-simpan').click(function () {

        let formData = new FormData($('#form-anggota')[0]);

        if ($('#username').val() === '' || $('#password').val() === '') {
            alert('Username dan Password wajib diisi');
            return false;
        }

        $.ajax({
            type: 'POST',
            url: '<?= site_url('registrasi-save') ?>',
            data: formData,
            processData: false,
            contentType: false,
            dataType: 'JSON',
            success: function (res) {
                if (res.status) {
                    alert('Registrasi berhasil');
                    window.location.href = '<?= site_url('login-sistem') ?>';
                }
            }
        });

        return false;
    });

});
</script>

</body>
</html>