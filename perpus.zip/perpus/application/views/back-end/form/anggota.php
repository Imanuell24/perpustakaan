<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-4">
                <div class="card card-primary">
                    <div class="card-header">
                        <h3 class="card-title"><i class="fas fa-users"></i> Form Anggota</h3>
                    </div>

                    <form id="form-anggota">
                        <div class="card-body">

                            <input type="hidden" id="id_siswa" name="id_siswa">
                            <input type="hidden" id="user_id" name="user_id">

                            <div class="form-group">
                                <label>NIS</label>
                                <input type="text" class="form-control form-control-sm" name="nis" id="nis" required>
                            </div>

                            <div class="form-group">
                                <label>Nama Siswa</label>
                                <input type="text" class="form-control form-control-sm" name="nm_siswa" id="nm_siswa" required>
                            </div>

                            <div class="form-group">
                                <label>Kelas</label>
                                <input type="text" class="form-control form-control-sm" name="kelas" id="kelas" required>
                            </div>

                            <div class="form-group">
                                <label>Alamat</label>
                                <textarea class="form-control form-control-sm" name="alamat" id="alamat" required></textarea>
                            </div>

                            <hr>
                            <small class="text-muted">Akun Login Anggota</small>

                            <div class="form-group mt-2">
                                <label>Username</label>
                                <input type="text" class="form-control form-control-sm" name="username" id="username" required>
                            </div>

                            <div class="form-group">
                                <label>Password</label>
                                <input type="password" class="form-control form-control-sm" name="password" id="password">
                                <small class="text-muted">Kosongkan jika tidak ingin ubah password (saat edit)</small>
                            </div>

                        </div>

                        <div class="card-footer text-right">
                            <button type="submit" class="btn btn-sm btn-primary" id="btn-simpan">
                                <i class="fas fa-save"></i> Simpan
                            </button>

                            <button type="button" class="btn btn-sm btn-warning d-none" id="btn-update">
                                <i class="fas fa-edit"></i> Update
                            </button>

                            <button type="button" class="btn btn-sm btn-secondary d-none" id="btn-batal">
                                <i class="fas fa-sync"></i> Batal
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <div class="col-md-8">
                <div class="card card-outline card-primary">
                    <div class="card-header">
                        <h3 class="card-title"><i class="fas fa-users"></i> Data Anggota</h3>
                    </div>

                    <div class="card-body table-responsive">
                       <table id="table-anggota" class="table table-bordered table-striped table-sm">
                            <thead class="text-center">
                                <tr>
                                    <th>No</th>
                                    <th>Detail</th>
                                    <th>Status</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php $no=1; foreach($result as $rs): ?>
                                <tr>
                                    <td><?= $no++ ?></td>
                                    <td>
                                        <b>NIS:</b> <?= $rs->nis ?><br>
                                        <b>Nama:</b> <?= $rs->nama ?><br>
                                        <b>Kelas:</b> <?= $rs->kelas ?><br>
                                        <b>Alamat:</b> <?= $rs->alamat ?>
                                    </td>
                                    <td class="text-center">
                                        <?php if($rs->status=='aktif'): ?>
                                            <button class="btn btn-success btn-sm"
                                                onclick="ubahStatus(<?= $rs->id ?>)"><i class="fas fa-eye"></i>
                                                Aktif
                                            </button>
                                        <?php else: ?>
                                            <button class="btn btn-danger btn-sm"
                                                onclick="ubahStatus(<?= $rs->id ?>)"><i class="fas fa-eye-slash"></i>
                                                Non Aktif
                                            </button>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center">
                                        <button class="btn btn-warning btn-sm"
                                            onclick="editData(<?= $rs->id ?>)"><i class="fas fa-edit"></i>
                                            Edit
                                        </button>
                                        <button class="btn btn-danger btn-sm"
                                            onclick="hapusData(<?= $rs->user_id ?>)"><i class="fas fa-trash"></i>
                                            Hapus
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>

<script>

$(document).ready(function(){

    $('#table-anggota').DataTable({
    ordering: false
    });

    $('#form-anggota').submit(function(e){
        e.preventDefault();

        let url = ($('#user_id').val() == '')
            ? "<?= site_url('back-end/anggota/save') ?>"
            : "<?= site_url('back-end/anggota/update') ?>";

        $.ajax({
            type: "POST",
            url: url,
            data: $(this).serialize(),
            dataType: "JSON",
            success: function(res){
                if(res.status){
                    location.reload();
                }else{
                    alert("Gagal menyimpan data");
                }
            }
        });
    });

    $('#btn-update').click(function(){
        $('#form-anggota').submit();
    });

    $('#btn-batal').click(function(){
        location.reload();
    });

});

function editData(id){
    $.getJSON("<?= site_url('back-end/anggota/edit/') ?>" + id, function(data){

        $('#id_siswa').val(data.id);
        $('#user_id').val(data.user_id);
        $('#nis').val(data.nis);
        $('#nm_siswa').val(data.nama);
        $('#kelas').val(data.kelas);
        $('#alamat').val(data.alamat);
        $('#username').val(data.username);
        $('#password').val('');

        $('#btn-simpan').addClass('d-none');
        $('#btn-update').removeClass('d-none');
        $('#btn-batal').removeClass('d-none');
    });
}

function hapusData(id){
    if(confirm("Yakin hapus data?")){
        $.get("<?= site_url('back-end/anggota/hapus/') ?>" + id, function(){
            location.reload();
        });
    }
}

function ubahStatus(id){
    $.get("<?= site_url('back-end/anggota/status/') ?>" + id, function(){
        location.reload();
    });
}
</script>