<?php
$role = $this->session->userdata('role');
?>

<div class="nav-left-sidebar sidebar-dark">
<style>

.nav-left-sidebar {
    background: linear-gradient(180deg, #0f172a, #1e293b);
    width: 250px;
}

.nav-left-sidebar .nav-link {
    position: relative;
    color: #cbd5e1;
    padding: 10px 20px;
    transition: all 0.3s ease;
    font-weight: 500;
    border-radius: 6px;
}

.nav-left-sidebar .nav-link:hover {
    background: linear-gradient(90deg, #2563eb, #3b82f6);
    color: #fff;
    transform: translateX(5px);
    box-shadow: 0 5px 15px rgba(37, 99, 235, 0.4);
}

.nav-left-sidebar .nav-link.active {
    background: linear-gradient(90deg, #2563eb, #3b82f6);
    color: #fff !important;
    box-shadow: 0 5px 15px rgba(37, 99, 235, 0.4);
}

.nav-divider {
    color: #94a3b8;
    font-size: 12px;
    padding-left: 20px;
    margin-top: 20px;
    text-transform: uppercase;
}

.submenu {
    background: rgba(255,255,255,0.03);
    padding-left: 10px;
}

.submenu .nav-link {
    font-size: 14px;
    color: #94a3b8;
}

.submenu .nav-link:hover {
    color: #fff;
}

.nav-link i {
    margin-right: 8px;
}

.nav-left-sidebar .nav-link::before {
    content: "";
    position: absolute;
    left: 0;
    top: 0;
    height: 100%;
    width: 0;
    background: #3b82f6;
    transition: width 0.3s ease;
    border-radius: 6px 0 0 6px;
}

.nav-left-sidebar .nav-link:hover::before,
.nav-left-sidebar .nav-link.active::before {
    width: 5px;
}
</style>

    <div class="menu-list">
        <nav class="navbar navbar-expand-lg navbar-light">
            <div class="collapse navbar-collapse show">
                <ul class="navbar-nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link <?= uri_string() == 'halaman-sistem' ? 'active' : '' ?>" 
                            href="<?= site_url('halaman-sistem') ?>">
                            <i class="fa fa-fw fa-home"></i> Dashboard
                        </a>
                    </li>

                    <?php if ($role === 'admin'): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="#" data-toggle="collapse"
                               data-target="#submenu-master">
                                <i class="fas fa-fw fa-database"></i> Master Data
                            </a>
                            <div id="submenu-master"  class="collapse submenu <?= 
                                (strpos(uri_string(), 'data-buku') !== false || 
                                strpos(uri_string(), 'data-anggota') !== false) 
                                ? 'show' : '' ?>">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link <?= strpos(uri_string(), 'data-buku') !== false ? 'active' : '' ?>" 
                                            href="<?= site_url('data-buku') ?>"><i class="fas fa-fw fa-book"></i>
                                            Data Buku
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link <?= strpos(uri_string(), 'data-anggota') !== false ? 'active' : '' ?>" 
                                            href="<?= site_url('data-anggota') ?>"><i class="fas fa-fw fa-user"></i>
                                            Data Anggota
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" data-toggle="collapse"
                               data-target="#submenu-transaksi">
                                <i class="fas fa-fw fa-exchange-alt"></i> Transaksi
                            </a>
                            <div id="submenu-transaksi" class="collapse submenu <?= 
                                (strpos(uri_string(), 'data-riwayat') !== false || 
                                strpos(uri_string(), 'data-peminjaman') !== false || 
                                strpos(uri_string(), 'data-pengembalian') !== false) 
                                ? 'show' : '' ?>">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link <?= strpos(uri_string(), 'data-riwayat') !== false ? 'active' : '' ?>" 
                                            href="<?= site_url('data-riwayat') ?>"><i class="fas fa-fw fa-history"></i>
                                            Riwayat Peminjaman
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link <?= strpos(uri_string(), 'data-peminjaman') !== false ? 'active' : '' ?>" 
                                            href="<?= site_url('data-peminjaman') ?>"><i class="fas fa-fw fa-book"></i>
                                            Data Peminjaman
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link <?= strpos(uri_string(), 'data-pengembalian') !== false ? 'active' : '' ?>" 
                                            href="<?= site_url('data-pengembalian') ?>"><i class="fas fa-fw fa-undo"></i>
                                            Data Pengembalian
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </li>

                    <?php elseif ($role === 'siswa'): ?>
                        <li class="nav-item">
                           <a class="nav-link <?= strpos(uri_string(), 'data-peminjaman') !== false ? 'active' : '' ?>" 
                                href="<?= site_url('data-peminjaman') ?>"><i class="fas fa-fw fa-book"></i>
                                Peminjaman
                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link <?= strpos(uri_string(), 'data-pengembalian') !== false ? 'active' : '' ?>" 
                                href="<?= site_url('data-pengembalian') ?>"><i class="fas fa-fw fa-undo"></i>
                                Pengembalian
                            </a>
                        </li>

                    <?php endif; ?>
                    <li class="nav-divider mt-3">SETTING</li>
                    <li class="nav-item">
                        <a class="nav-link text-danger"
                           href="<?= site_url('logout-sistem') ?>"
                           onclick="return confirm('Yakin logout?')">
                            <i class="fas fa-fw fa-sign-out-alt"></i> Logout
                        </a>
                    </li>

                </ul>
            </div>
        </nav>
    </div>
</div>
