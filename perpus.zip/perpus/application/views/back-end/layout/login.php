<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Login Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap -->
    <link rel="stylesheet" href="<?= base_url('assets/vendor/bootstrap/css/bootstrap.min.css') ?>">
    <link rel="stylesheet" href="<?= base_url('assets/vendor/fontawesome/css/all.min.css') ?>">

    <style>
        body {
            background: linear-gradient(135deg, #1e3a8a, #02193f);
             /* background: url('<?= base_url("assets/images/bg33.jpg") ?>') no-repeat center center fixed;
            background-size: cover; */
        }

        .login-wrapper {
            min-height: 100vh;
        }

        .login-card {
            border-radius: 15px;
            background: rgba(255,255,255,0.95);
            backdrop-filter: blur(10px);
        }

        .login-header {
            color: #1e40af;
            border-radius: 12px 12px 0 0;
        }

        .form-control {
            border-radius: 10px;
        }

        .btn-primary {
            background: linear-gradient(135deg, #2563eb, #3b82f6);
            border: none;
        }

        .btn-primary:hover {
            background: linear-gradient(135deg, #1e40af, #2563eb);
        }
    </style>
</head>

<body>

<div class="container login-wrapper d-flex justify-content-center align-items-center">
    <div class="col-lg-4 col-md-7 col-sm-11">

        <div class="card login-card shadow-lg">
            <div class="card-header login-header text-center">
                <h4 class="mb-0"><b>CALZ</b> SCHOOl</h4>
            </div>

            <div class="card-body">
                <p class="text-center text-muted small">
                    Sign in to start your session
                </p>

                <form action="<?= site_url('auth_login/login') ?>" method="post">

                    <div class="form-group mb-3">
                        <label>Username</label>
                        <input type="text" name="username"
                               class="form-control"
                               placeholder="Masukkan username"
                               required>
                    </div>

                    <div class="form-group mb-4">
                        <label>Password</label>
                        <input type="password" name="password"
                               class="form-control"
                               placeholder="Masukkan password"
                               required>
                    </div>

                    <button class="btn btn-primary btn-block">
                        <i class="fa fa-sign-in-alt"></i> Login
                    </button>

                    <a href="<?= site_url('registrasi-anggota') ?>"
                       class="btn btn-outline-primary btn-block mt-2">
                        <i class="fa fa-user-plus"></i> Registrasi
                    </a>

                </form>
            </div>
        </div>

    </div>
</div>

<script src="<?= base_url('assets/libs/js/jquery.min.js') ?>"></script>
<script src="<?= base_url('assets/vendor/bootstrap/js/bootstrap.bundle.min.js') ?>"></script>

</body>
</html>
