<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Main extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

        if (!$this->session->userdata('logged')) {
            redirect('login-sistem');
            exit;
        }

        $this->load->model('Dashboard_model', 'dashboard');
    }

    public function index()
    {
        $data['page']  = 'back-end/dashboard';
        $data['judul'] = 'Dashboard';
        $data['total_anggota']      = $this->dashboard->countAnggota();
        $data['total_buku']         = $this->dashboard->countBuku();
        $data['total_peminjaman']   = $this->dashboard->countPeminjaman();
        $data['total_pengembalian'] = $this->dashboard->countPengembalian();

        $this->load->view('back-end/layout/header', $data);
        $this->load->view('back-end/layout/navbar');
        $this->load->view('back-end/layout/sidebar');
        $this->load->view('back-end/layout/content', $data);
        $this->load->view('back-end/layout/footer');
    }
}