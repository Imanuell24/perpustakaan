/*
SQLyog Enterprise v12.09 (64 bit)
MySQL - 10.4.27-MariaDB : Database - perpustakaan
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`perpustakaan` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;

USE `perpustakaan`;

/*Table structure for table `anggota` */

DROP TABLE IF EXISTS `anggota`;

CREATE TABLE `anggota` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(50) DEFAULT NULL,
  `nis` varchar(50) DEFAULT NULL,
  `kelas` varchar(50) DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `status` enum('aktif','nonaktif') DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

/*Data for the table `anggota` */

insert  into `anggota`(`id`,`user_id`,`nis`,`kelas`,`alamat`,`status`) values (9,'11','21202629','XII RPL','Jln Kemayoran Jonggol','aktif'),(4,'5','2157852313','XII RPL','sdfszd','aktif'),(7,'8','263541623','XII RPL','Jln. Jakarta Banjir','aktif'),(8,'10','4323234234','XII RPL','Jln Griya Alam Sentosa','aktif'),(10,'12','023920203','XII DKV','Jln. Jonggol Cipecang','aktif'),(12,'15','02902912','XII RPL','Jln. Cipecang Limus','aktif'),(13,'16','83202302','XII DKV','Jln. Pasir Angin','aktif'),(14,'17','','','','aktif'),(15,'18','766435436','XII RPL','Jln. Sitorus Batak','aktif'),(16,'19','02902912','XII DKV','Jln. Manggis Asri','aktif');

/*Table structure for table `buku` */

DROP TABLE IF EXISTS `buku`;

CREATE TABLE `buku` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `kode_buku` varchar(50) DEFAULT NULL,
  `judul` varchar(50) DEFAULT NULL,
  `pengarang` varchar(50) DEFAULT NULL,
  `penerbit` varchar(50) DEFAULT NULL,
  `tahun` year(4) DEFAULT NULL,
  `stok` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

/*Data for the table `buku` */

insert  into `buku`(`id`,`kode_buku`,`judul`,`pengarang`,`penerbit`,`tahun`,`stok`) values (4,'NCS-291','Night For All','Keyboard Law','Purnowo Bambang',2020,16),(3,'BCS-456','Karangan Si Kancil','Budi','Kendi',2003,0),(5,'LMD-983','Ahli Pewaris ','Chi na bos','Master Liu Kang',1999,14),(6,'BNL-202','Fitnah Kejam','Rahmat Tahalu','Bintang Rama',2019,6),(7,'SKS-671','Siksa Neraka','Mahmud Amin','Alex Siregar',1993,2);

/*Table structure for table `peminjaman` */

DROP TABLE IF EXISTS `peminjaman`;

CREATE TABLE `peminjaman` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `anggota_id` int(20) DEFAULT NULL,
  `tgl_pinjam` date DEFAULT NULL,
  `tgl_kembali` date DEFAULT NULL,
  `status` enum('dipinjam','kembali') DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

/*Data for the table `peminjaman` */

insert  into `peminjaman`(`id`,`anggota_id`,`tgl_pinjam`,`tgl_kembali`,`status`) values (1,0,'2026-01-22','2026-01-22',''),(6,7,'2026-02-25','2000-02-21',''),(3,6,'2026-02-24','2026-02-25','dipinjam'),(4,7,'2026-02-24','2026-02-25',''),(5,7,'2026-02-25','2000-02-21',''),(7,10,'2026-02-25','2026-02-27',''),(8,9,'2026-02-25','2026-02-24',''),(9,9,'2026-02-25','2026-02-23',''),(10,8,'2026-02-25','2026-02-27',''),(11,12,'2026-02-25','2026-02-27',''),(12,8,'2026-02-25','2026-02-26',''),(13,13,'2026-02-25','2026-02-27',''),(14,13,'2026-02-25','2026-02-28','dipinjam'),(15,10,'2026-02-25','2026-02-28','dipinjam'),(16,8,'2026-02-25','2026-02-27','dipinjam'),(17,7,'2026-02-25','2026-02-27','dipinjam'),(18,12,'2026-02-25','2026-02-28','dipinjam'),(19,15,'2026-02-25','2026-02-28','dipinjam'),(20,13,'2026-02-25','2026-02-28','dipinjam'),(21,16,'2026-02-25','2026-02-01','dipinjam');

/*Table structure for table `peminjaman_detail` */

DROP TABLE IF EXISTS `peminjaman_detail`;

CREATE TABLE `peminjaman_detail` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `peminjaman_id` int(20) DEFAULT NULL,
  `buku_id` int(20) DEFAULT NULL,
  `qty` int(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

/*Data for the table `peminjaman_detail` */

insert  into `peminjaman_detail`(`id`,`peminjaman_id`,`buku_id`,`qty`) values (1,1,2,1),(2,1,2,1),(3,1,2,1),(4,1,2,1),(5,1,2,1),(6,2,2,1),(7,3,3,1),(8,4,2,1),(9,5,3,1),(10,6,4,1),(11,7,4,1),(12,8,3,1),(13,9,3,1),(14,10,4,2),(15,11,4,1),(16,12,3,1),(17,13,5,1),(18,14,5,1),(19,14,3,1),(20,14,4,1),(21,15,5,1),(22,15,3,1),(23,15,4,1),(24,16,4,1),(25,16,3,1),(26,16,5,1),(27,17,5,1),(28,18,4,1),(29,18,3,1),(30,18,5,1),(31,19,3,6),(32,20,6,1),(33,20,7,1),(34,21,5,1);

/*Table structure for table `pengembalian` */

DROP TABLE IF EXISTS `pengembalian`;

CREATE TABLE `pengembalian` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `peminjaman_id` int(20) DEFAULT NULL,
  `tgl_pengembalian` date DEFAULT NULL,
  `denda` decimal(10,0) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

/*Data for the table `pengembalian` */

insert  into `pengembalian`(`id`,`peminjaman_id`,`tgl_pengembalian`,`denda`) values (1,1,'2026-01-22','1000'),(4,6,'2026-02-25','19002000'),(3,5,'2026-02-25','19002000'),(5,7,'2026-02-25','0'),(6,8,'2026-02-25','2000'),(7,10,'2026-02-25','0'),(8,9,'2026-02-25','4000'),(9,11,'2026-02-25','0'),(10,13,'2026-02-25','0'),(11,12,'2026-02-25','0');

/*Table structure for table `users` */

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` text DEFAULT NULL,
  `role` enum('admin','siswa') DEFAULT NULL,
  `created_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

/*Data for the table `users` */

insert  into `users`(`id`,`nama`,`username`,`password`,`role`,`created_at`) values (11,'Abdul','bedul','$2y$10$Ypdrw43kEy/w.JPKJlEIxOwEVqh4Rm41QOy68vJOQzQAYsShKh2TS','siswa',NULL),(9,'admin','admin','$2y$10$NB2WQ0EX7adIcs.S/ybRv.C6il759Bm38VSwn1r516t4W39uTc1.2','admin',NULL),(8,'Aditya','pol','$2y$10$CcZOzX0g5LfPS3thMds5hOT8CSSfikBibNp4XpiiU4tz5jsKNtRwS','siswa','2026-02-25 08:26:10'),(10,'Iman Saputra','iman','$2y$10$eRIHlXiixBt.sQhFzpu94uURbWsi1cyTE4HlekSFwTc3FovoAQdMe','siswa','2026-02-25 09:57:44'),(12,'Willdan Nurrahman','willdan','$2y$10$75YNp1ZdHJyXQehhFezDn.bJri05UsNNpGSk5ih4XwwRMRrjb8dEu','siswa','2026-02-25 13:05:15'),(15,'Deny Anggara ','deny','$2y$10$HuJYYcYxcTD5dYEZnjXwkudLINaCpiuJaAfISkFvcUJS9BYVGqX1G','siswa',NULL),(14,'CalZ','calz','$2y$10$FtrnOQlBlwuefd5A7Hsd4uVwsWND1qIB3KdMb3huYCecGiuYJLRma','admin','2026-02-25 09:40:40'),(16,'Alwi Kobra','alwi','$2y$10$W0d7DDp93NAYeXGrf63YluV2./RqFX21f/yR9D698/hsZBtG6zYk.','siswa',NULL),(18,'Raja Nugroho','raja','$2y$10$A4oFlFXXPj0rYWBLciAP2OpPv1FwIoXLDGAGVqYF844sQRhKLkOyS','siswa',NULL),(19,'Haikal Teuku','haikal','$2y$10$294O.bKiRjZqHVY20hTmEuArJ7rSAZ4aL2cx1lsekF.jDvjvXjHaS','siswa',NULL);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
